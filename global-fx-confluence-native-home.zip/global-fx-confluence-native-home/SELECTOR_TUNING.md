# CSS 选择器适配说明

Confluence 不同版本、主题和第三方插件可能改变部分 HTML class，因此这套 CSS deliberately 使用两种相对稳定的标记：

1. 原生 Anchor 宏生成的 `.confluence-anchor-link`
2. 原生 Panel 常见的 `.panel`、`.panelHeader`、`.panelContent`

## 页面标记为什么使用 Anchor

Space Stylesheet 会作用于整个 Space。首页最顶部的 `gfx-home` Anchor 让样式使用以下逻辑：

```css
.wiki-content:has(.confluence-anchor-link[id$="-gfx-home"]) { ... }
```

即：只有包含 `gfx-home` Anchor 的页面才应用首页样式。

Confluence 常把 Anchor 的实际 ID 渲染为：

```text
PageTitle-gfx-home
```

所以选择器使用 `$="-gfx-home"`，而不是要求 ID 必须完全等于 `gfx-home`。

## 如果页面完全没有变化

在查看模式打开首页，按 F12，检查 `gfx-home` Anchor 的实际 HTML。

可能看到：

```html
<span class="confluence-anchor-link" id="GlobalFXPlatform-gfx-home"></span>
```

这种情况不需要改 CSS。

若 class 或 ID 格式不同，把实际片段与 `space-stylesheet.css` 顶部的作用域选择器进行对照。

## 如果只有 Panel 样式没有生效

检查 Panel 查看模式 HTML 是否仍使用：

```html
<div class="panel">
  <div class="panelHeader">...</div>
  <div class="panelContent">...</div>
</div>
```

如果你们的主题替换了这些 class，只需要统一替换 CSS 中：

```text
.panel
.panelHeader
.panelContent
```

不要先修改颜色和间距规则。

## 浏览器不支持 `:has()` 时

现代浏览器通常可以执行这套 CSS。若企业环境中的旧浏览器不能识别 `:has()`，需要改用你们实例实际提供的 page ID/body attribute 作为首页作用域。

操作方法：

1. 打开首页查看模式。
2. F12 检查 `<body>`、`<html>` 或 `#main-content`。
3. 找到只属于当前页的属性，例如 page/content ID。
4. 用它替换每条规则开头的 `.wiki-content:has(...)`。

不要盲目使用网上某个固定的 `data-content-id` 选择器，因为它取决于 Confluence 版本和主题输出。

## 编辑模式异常

Space CSS 也可能影响编辑页面。当前 CSS 主要限制在 `.wiki-content`，以减少对编辑器的影响。若某一版本仍出现编辑器重叠：

1. 暂时移除最后添加的规则。
2. 检查该规则是否修改了 `display`、`position`、`width` 或 `overflow`。
3. 尽量仅对 `.panelContent` 内部元素设置样式。
