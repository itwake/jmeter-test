# Global FX Platform — Native Confluence Homepage

这是一个面向 Confluence Data Center / Server 私有化部署的原生首页样式包。

## 与上一版完整 HTML 的区别

- 不部署 Nginx 静态网站
- 不使用 iframe
- 不使用 HTML Macro
- 不注入 JavaScript
- 页面仍可通过 Confluence 编辑器逐块维护
- 使用 Space Custom CSS 统一美化原生宏

## 文件

```text
space-stylesheet.css                 可粘贴到 Space Stylesheet 的 CSS
PAGE_BUILD_GUIDE.md                  按区块搭建首页的操作说明
SELECTOR_TUNING.md                   不同 Confluence 版本的选择器适配说明
reference/global-fx-home-reference.png  视觉参考图
```

## 最小可行验证

1. 新建或编辑 Global FX Platform 首页。
2. 页面顶部添加 Anchor：`gfx-home`。
3. 添加一个 Panel；Panel 内第一项添加 Anchor：`gfx-hero`。
4. Panel 内加入欢迎标题和一句描述。
5. 把 `space-stylesheet.css` 粘贴到 Space tools → Look and Feel → Stylesheet。
6. 保存并强制刷新。

确认 Hero 生效后，再按照 `PAGE_BUILD_GUIDE.md` 一块块添加其余内容。

## 功能边界

Space CSS 负责视觉，不负责数据和行为：

- Current Status 的自动更新需要现有状态宏或集成。
- Ask AI 的 API 调用需要 User Macro、插件或外部页面。
- CSS 无法替代搜索、权限、接口调用和服务端逻辑。
