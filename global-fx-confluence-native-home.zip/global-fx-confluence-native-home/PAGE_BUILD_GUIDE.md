# Global FX Platform 首页：原生 Confluence 搭建指南

这个方案不嵌入完整 HTML，也不使用 iframe。首页由 Confluence 原生页面布局、Panel、Livesearch、Recently Updated、Content by Label、Status 和普通链接组成；Space Custom CSS 只改变视觉样式。

## 1. 页面总体结构

建议页面标题保留为：

```text
Global FX Platform
```

在页面最顶部插入一个 **Anchor 宏**：

```text
gfx-home
```

这是首页标记。CSS 只有在检测到该 Anchor 时才生效，因此不会把同一个 Space 的普通文档都改成首页卡片样式。

随后按以下顺序搭建：

```text
[一列]
  Hero Panel

[一列]
  Search Panel

[四列]
  Quick Actions | Popular Resources | Current Status | Engineering / Platform Tools

[两列]
  Recently Updated | Announcements
```

## 2. Hero 区块

插入一个 **Panel 宏**，标题留空。在 Panel 内按顺序放置：

1. Anchor 宏：`gfx-hero`
2. Heading 1 或 Heading 2：`🌐 Welcome to Global FX Platform`
3. 普通文本：`Your central hub for FX platform documentation, operations, releases, and support.`

Panel 自带的边框、背景色都可以保持默认；CSS 会覆盖。

## 3. 搜索区块

插入一个 Panel：

- Panel title：`What do you need help with?`
- 第一项 Anchor：`gfx-search`
- 说明：`Search this space for platform documentation, runbooks, releases, and support information.`
- 插入 **Livesearch 宏**

Livesearch 建议配置：

```text
Space: 当前 Global FX Platform Space，或明确填写 Space Key
Content type: Page
Placeholder: Search Global FX Platform...
Maximum results: 8
```

Livesearch 可以原生限制搜索当前 Space。

CSS 本身不能调用 AI API。可以在搜索 Panel 下方增加普通链接：

```text
✨ Ask AI Agent
```

链接到现有 AI Agent 页面即可。若必须在当前页面输入问题并直接调用 Agent API，则需要 User Macro、插件或 iframe，不是纯 CSS 能实现的功能。

## 4. Quick Actions

创建一个 Panel：

- Panel title：`⚡ I want to...`
- 第一项 Anchor：`gfx-actions`
- 下面使用普通无序列表，每行仅放一个链接

示例：

```text
✅ Check production status
📘 Find a runbook
🔐 Request platform access
🗓 View release calendar
🚨 Investigate an incident
👥 Check service ownership
✨ Ask AI Agent
```

最后一项会被 CSS 强调成 AI 入口。需要改变哪一项被强调时，可调整 CSS 中 `li:last-child` 的规则。

## 5. Popular Resources

创建一个 Panel：

- Panel title：`🔖 Popular Resources`
- 第一项 Anchor：`gfx-resources`
- 使用普通无序列表，每行一个链接

推荐内容：

```text
Getting Started
Architecture Overview
FX Trading Services
Production Runbook
Release Guide
Support FAQ
```

## 6. Current Status

创建一个 Panel：

- Panel title：`〽 Current Status`
- 第一项 Anchor：`gfx-status`
- 插入两列表格

示例：

| Service | Status |
|---|---|
| Pricing Engine | Status 宏：Operational / Green |
| Trade Capture | Status 宏：Operational / Green |
| Market Data | Status 宏：Operational / Green |
| Settlement Gateway | Status 宏：Degraded / Yellow |
| Client API | Status 宏：Operational / Green |

如果状态已经存在于 Grafana、Jira、Statuspage 或其他系统，原生表格只能手工维护。自动同步需要相应插件、宏或 API 集成。

## 7. Engineering / Platform Tools

创建一个 Panel：

- Panel title：`🛠 Engineering / Platform Tools`
- 第一项 Anchor：`gfx-tools`
- 使用普通无序列表

示例：

```text
GitHub
Jenkins
AWS Console
Grafana
Kibana / Logs Explorer
Jira
```

每个文字直接链接到内网真实地址。

## 8. Recently Updated

创建一个 Panel：

- Panel title：`◷ Recently Updated`
- 第一项 Anchor：`gfx-updates`
- 插入 **Recently Updated 宏**

建议配置：

```text
Space: 当前 Space
Content type: Pages
Maximum items: 5 或 8
```

## 9. Announcements

创建一个 Panel：

- Panel title：`📣 Announcements`
- 第一项 Anchor：`gfx-announcements`

推荐二选一：

### 方案 A：Content by Label

给公告页面添加统一标签：

```text
gfx-announcement
```

首页插入 Content by Label 宏，限制当前 Space，最多显示 5 条。

### 方案 B：Blog Posts

团队习惯用 Blog 发布变更和公告时，使用 Blog Posts 宏，并限制当前 Space 与显示数量。

## 10. 应用 CSS

以 Space Admin 身份进入：

```text
Space tools → Look and Feel → Stylesheet → Edit
```

复制 `space-stylesheet.css` 的全部内容，保存并强制刷新浏览器。

若看不到 Stylesheet，通常是系统管理员尚未启用 Space Custom Stylesheets。需要系统管理员在全局安全配置中开启。

## 11. 建议的分阶段调整

不要一次改所有区块。推荐顺序：

1. 先只放 `gfx-home`、Hero 和 Search，粘贴 CSS 验证作用域。
2. 增加 Quick Actions 和 Popular Resources。
3. 增加 Current Status 和 Tools。
4. 最后增加 Recently Updated 和 Announcements。
5. 每增加一个区块都检查查看模式、编辑模式、移动端和深色主题。

## 12. 回滚

修改前把当前 Space Stylesheet 保存到本地。若样式异常：

1. 进入 Space tools → Look and Feel → Stylesheet。
2. 删除本次新增部分，或恢复之前备份。
3. 保存后执行强制刷新。

不要使用会隐藏编辑按钮、Space Tools 或权限相关控件的规则。
