import os
import subprocess
import boto3
import argparse
import hashlib
import requests
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor

MAX_WORKERS = 8

def get_git_email():
    try:
        result = subprocess.run(["git", "config", "user.email"], capture_output=True, text=True)
        return result.stdout.strip()
    except Exception:
        return None

def get_temporary_credentials(auth_url, email):
    resp = requests.post(auth_url, json={"email": email})
    creds = resp.json()
    session = boto3.Session(
        aws_access_key_id=creds["AccessKeyId"],
        aws_secret_access_key=creds["SecretAccessKey"],
        aws_session_token=creds["SessionToken"]
    )
    return session.client("s3"), creds["BucketName"]

def md5_checksum(path):
    hash_md5 = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()

def list_local_files(folder):
    files = {}
    for root, _, filenames in os.walk(folder):
        for filename in filenames:
            full = os.path.join(root, filename)
            rel = os.path.relpath(full, folder).replace("\", "/")
            files[rel] = {
                "path": full,
                "md5": md5_checksum(full),
                "mtime": datetime.utcfromtimestamp(os.path.getmtime(full)).replace(tzinfo=timezone.utc)
            }
    return files

def list_s3_files(s3, bucket):
    result = {}
    resp = s3.list_objects_v2(Bucket=bucket)
    for obj in resp.get("Contents", []):
        result[obj["Key"]] = {
            "etag": obj["ETag"].strip('"'),
            "last_modified": obj["LastModified"]
        }
    return result

def upload_file(s3, bucket, key, path):
    s3.upload_file(path, bucket, key)
    print(f"Uploaded {key}")

def download_file(s3, bucket, key, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    s3.download_file(bucket, key, path)
    print(f"Downloaded {key}")

def sync(s3, bucket, local_folder):
    local = list_local_files(local_folder)
    remote = list_s3_files(s3, bucket)
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        for key, meta in local.items():
            if key not in remote or meta["md5"] != remote[key]["etag"]:
                executor.submit(upload_file, s3, bucket, key, meta["path"])
        for key in remote:
            if key not in local:
                path = os.path.join(local_folder, key)
                executor.submit(download_file, s3, bucket, key, path)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--auth-url", required=True)
    parser.add_argument("--local-folder", default="./sync-folder")
    args = parser.parse_args()

    git_email = get_git_email()
    if not git_email:
        print("Git email not found.")
        exit(1)

    s3, bucket = get_temporary_credentials(args.auth_url, git_email)
    sync(s3, bucket, args.local_folder)