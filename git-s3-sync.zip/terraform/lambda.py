import boto3
import json
import os

ssm = boto3.client("ssm")
sts = boto3.client("sts")

def handler(event, context):
    email = json.loads(event["body"]).get("email")
    param = ssm.get_parameter(Name="/auth/whitelist", WithDecryption=False)
    allowed_emails = param["Parameter"]["Value"].split(",")

    if email not in allowed_emails:
        return {"statusCode": 403, "body": json.dumps({"error": "Unauthorized"})}

    resp = sts.assume_role(
        RoleArn="arn:aws:iam::<your-account-id>:role/S3AccessRole",
        RoleSessionName=email.replace("@", "_")
    )
    creds = resp["Credentials"]
    return {
        "statusCode": 200,
        "body": json.dumps({
            "AccessKeyId": creds["AccessKeyId"],
            "SecretAccessKey": creds["SecretAccessKey"],
            "SessionToken": creds["SessionToken"],
            "BucketName": "your-bucket-name"
        })
    }