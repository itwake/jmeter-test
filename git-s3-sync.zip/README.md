# Git-based AWS S3 Sync with API Gateway Auth

## 功能概述

- 使用本地 Python 工具同步本地目录与 S3（支持多线程上传/下载）
- 使用 API Gateway 获取访问凭证（基于 Git 用户邮箱验证）
- 邮箱白名单存储于 AWS SSM Parameter Store

## 使用方法

### 1. 设置本地 Git 用户信息

确保你已经设置：

```bash
git config --global user.name "Your Name"
git config --global user.email "you@example.com"
```

### 2. 部署 AWS 基础设施

```bash
cd terraform
terraform init
terraform apply
```

### 3. 同步文件

```bash
python s3_sync_client.py --auth-url https://your-api-id.execute-api.region.amazonaws.com/auth
```

支持参数：

- `--dryrun`: 模拟同步
- `--include "*.txt"`: 只同步特定文件
- `--exclude "*.log"`: 排除特定文件