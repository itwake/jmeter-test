
import os
import sys
import hashlib
import json
import requests
from datetime import datetime

API_URL = "https://your-api-id.execute-api.region.amazonaws.com/files"
JWT_TOKEN = os.environ.get("JWT_TOKEN")
HEADERS = {"Authorization": f"Bearer {JWT_TOKEN}"}

def md5sum(filename):
    with open(filename, 'rb') as f:
        return hashlib.md5(f.read()).hexdigest()

def list_remote():
    r = requests.get(API_URL, headers=HEADERS)
    return {f["Key"]: f["LastModified"] for f in r.json()}

def upload(file):
    with open(file, "rb") as f:
        headers = HEADERS.copy()
        headers["file-name"] = file
        r = requests.post(API_URL, headers=headers, data=f.read())
        print(r.json())

def download(file):
    r = requests.get(API_URL, headers=HEADERS, params={"file": file})
    with open(file, "wb") as f:
        f.write(r.content)
    print(f"Downloaded {file}")

def delete(file):
    r = requests.delete(API_URL, headers=HEADERS, params={"file": file})
    print(r.json())

def sync():
    remote = list_remote()
    for file in os.listdir("."):
        if os.path.isfile(file):
            mtime = datetime.utcfromtimestamp(os.path.getmtime(file)).isoformat()
            if file not in remote or mtime > remote[file]:
                print(f"Uploading {file}")
                upload(file)
    for rfile in remote:
        if not os.path.exists(rfile):
            print(f"Downloading {rfile}")
            download(rfile)

if __name__ == "__main__":
    cmd = sys.argv[1]
    if cmd == "sync":
        sync()
    elif cmd == "upload":
        upload(sys.argv[2])
    elif cmd == "download":
        download(sys.argv[2])
    elif cmd == "delete":
        delete(sys.argv[2])
