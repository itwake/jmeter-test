
import boto3
import base64
import json
import os
import time
import jwt

s3 = boto3.client('s3')
BUCKET = os.environ.get('BUCKET')
JWT_SECRET = os.environ.get('JWT_SECRET')

def validate_jwt(token):
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=['HS256'])
        return True
    except Exception as e:
        return False

def lambda_handler(event, context):
    headers = event.get("headers", {})
    auth_header = headers.get("Authorization", "")
    token = auth_header.replace("Bearer ", "")

    if not validate_jwt(token):
        return {"statusCode": 401, "body": json.dumps({"error": "Unauthorized"})}

    method = event['requestContext']['http']['method']
    path = event['rawPath']
    query = event.get("queryStringParameters") or {}

    if method == 'POST':
        file_name = headers.get('file-name')
        file_content = base64.b64decode(event['body'])
        s3.put_object(Bucket=BUCKET, Key=file_name, Body=file_content)
        return {"statusCode": 200, "body": json.dumps({"message": "Uploaded"})}
    elif method == 'GET':
        file_name = query.get("file")
        if file_name:
            obj = s3.get_object(Bucket=BUCKET, Key=file_name)
            content = base64.b64encode(obj['Body'].read()).decode()
            return {"statusCode": 200, "body": content, "isBase64Encoded": True}
        else:
            objs = s3.list_objects_v2(Bucket=BUCKET).get("Contents", [])
            file_list = [{"Key": o["Key"], "LastModified": o["LastModified"].isoformat()} for o in objs]
            return {"statusCode": 200, "body": json.dumps(file_list)}
    elif method == 'DELETE':
        file_name = query.get("file")
        if file_name:
            s3.delete_object(Bucket=BUCKET, Key=file_name)
            return {"statusCode": 200, "body": json.dumps({"message": "Deleted"})}
        else:
            return {"statusCode": 400, "body": json.dumps({"error": "No file specified"})}
    else:
        return {"statusCode": 400, "body": json.dumps({"error": "Bad request"})}
