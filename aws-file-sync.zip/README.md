# AWS File Sync

A JWT-protected file sync system using API Gateway + Lambda + S3.