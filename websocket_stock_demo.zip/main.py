from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse
import uvicorn
import asyncio
import json
import itertools

app = FastAPI()
clients = set()

@app.get("/")
async def get():
    with open("index.html", encoding="utf-8") as f:
        return HTMLResponse(content=f.read(), status_code=200)

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    clients.add(websocket)
    try:
        # Load static data
        with open("static_data.json", encoding="utf-8") as f:
            data_list = json.load(f)
        for entry in itertools.cycle(data_list):
            for client in clients:
                await client.send_json(entry)
            await asyncio.sleep(2)
    except WebSocketDisconnect:
        clients.remove(websocket)

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
