# Agent Flow

## Routine maintenance

```text
User: Check HAProxy AMI status
        |
        v
amiops check --config config.json --type haproxy
        |
        +-- healthy=true ------------------------> Agent summarizes; stop
        |
        +-- change_needed=true
                |
                v
amiops reconcile --config config.json --type haproxy
                |
                v
Agent explains exact planned actions
                |
             approval
                |
                v
amiops reconcile --config config.json --type haproxy --apply
                |
                v
amiops check --config config.json --type haproxy
```

## Token-saving rules

- Prefer `check` over multiple low-level calls.
- Compact JSON is the default.
- Do not ask the Agent to sort AMIs, compare timestamps, identify clones, or resolve Launch Templates itself.
- Keep business rules in Go.
- Add new deterministic behaviors behind existing high-level commands when possible.
- Add a new command only when the intent is genuinely different, not just because an AWS API is different.
