# Suggested Roadmap

## v0.1 - included

- Stable JSON envelope.
- Self-describing capabilities.
- Config validation.
- AWS identity doctor.
- Latest AMI selection.
- Cross-region clone detection.
- Direct Launch Template / Launch Configuration ASG compliance.
- Dry-run reconcile.
- Apply missing AMI copies.
- Go-only cross-platform build helper.

## v0.2 - recommended

- ASG Launch Template update action.
- Idempotent action IDs / operation journal.
- Instance Refresh as an explicit separate action.
- Configurable minimum AMI age / bake grace period.
- Clone SLA evaluation.

## v0.3

- EC2 post-deployment health.
- CloudWatch error/log signals.
- AMI scan status integration.
- Maintenance policy windows.
- Audit event output for enterprise ingestion.

## Design rule

Do not grow the Agent prompt as features grow. Extend the Go runtime and keep `check/reconcile/apply/verify` as the primary interaction model.
