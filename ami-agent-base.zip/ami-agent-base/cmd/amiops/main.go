package main

import (
	"os"

	"github.com/your-org/ami-agent-base/internal/cli"
)

func main() {
	r := cli.Runner{Stdout: os.Stdout, Stderr: os.Stderr}
	os.Exit(r.Run(os.Args[1:]))
}
