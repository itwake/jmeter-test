package awsx

import (
	"context"
	"fmt"
	"sync"

	awsconfig "github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/service/autoscaling"
	"github.com/aws/aws-sdk-go-v2/service/ec2"
	"github.com/aws/aws-sdk-go-v2/service/sts"
)

type RegionalClients struct {
	EC2         *ec2.Client
	AutoScaling *autoscaling.Client
	STS         *sts.Client
}

type Factory struct {
	profile string
	mu      sync.Mutex
	cache   map[string]*RegionalClients
}

func NewFactory(profile string) *Factory {
	return &Factory{profile: profile, cache: make(map[string]*RegionalClients)}
}

func (f *Factory) ForRegion(ctx context.Context, region string) (*RegionalClients, error) {
	f.mu.Lock()
	if c, ok := f.cache[region]; ok {
		f.mu.Unlock()
		return c, nil
	}
	f.mu.Unlock()

	opts := []func(*awsconfig.LoadOptions) error{awsconfig.WithRegion(region)}
	if f.profile != "" {
		opts = append(opts, awsconfig.WithSharedConfigProfile(f.profile))
	}
	cfg, err := awsconfig.LoadDefaultConfig(ctx, opts...)
	if err != nil {
		return nil, fmt.Errorf("load AWS config for region %s: %w", region, err)
	}
	clients := &RegionalClients{
		EC2:         ec2.NewFromConfig(cfg),
		AutoScaling: autoscaling.NewFromConfig(cfg),
		STS:         sts.NewFromConfig(cfg),
	}

	f.mu.Lock()
	if existing, ok := f.cache[region]; ok {
		f.mu.Unlock()
		return existing, nil
	}
	f.cache[region] = clients
	f.mu.Unlock()
	return clients, nil
}
