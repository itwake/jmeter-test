package output

import (
	"encoding/json"
	"fmt"
	"io"
	"time"
)

type ErrorDetail struct {
	Code      string `json:"code"`
	Message   string `json:"message"`
	Retryable bool   `json:"retryable"`
}

type Envelope struct {
	OK        bool         `json:"ok"`
	Command   string       `json:"command"`
	Timestamp string       `json:"timestamp"`
	Data      any          `json:"data,omitempty"`
	Error     *ErrorDetail `json:"error,omitempty"`
}

type AppError struct {
	Code      string
	Message   string
	Retryable bool
	ExitCode  int
}

func (e *AppError) Error() string { return e.Message }

func NewError(code, message string, retryable bool, exitCode int) *AppError {
	return &AppError{Code: code, Message: message, Retryable: retryable, ExitCode: exitCode}
}

func WriteSuccess(w io.Writer, command string, data any, pretty bool) error {
	return write(w, Envelope{OK: true, Command: command, Timestamp: time.Now().UTC().Format(time.RFC3339), Data: data}, pretty)
}

func WriteError(w io.Writer, command string, appErr *AppError, pretty bool) error {
	return write(w, Envelope{
		OK:        false,
		Command:   command,
		Timestamp: time.Now().UTC().Format(time.RFC3339),
		Error:     &ErrorDetail{Code: appErr.Code, Message: appErr.Message, Retryable: appErr.Retryable},
	}, pretty)
}

func write(w io.Writer, v any, pretty bool) error {
	enc := json.NewEncoder(w)
	enc.SetEscapeHTML(false)
	if pretty {
		enc.SetIndent("", "  ")
	}
	if err := enc.Encode(v); err != nil {
		return fmt.Errorf("encode JSON: %w", err)
	}
	return nil
}
