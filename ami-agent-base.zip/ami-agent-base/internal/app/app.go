package app

import (
	"context"
	"fmt"
	"sort"
	"time"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/autoscaling"
	autotypes "github.com/aws/aws-sdk-go-v2/service/autoscaling/types"
	"github.com/aws/aws-sdk-go-v2/service/ec2"
	ec2types "github.com/aws/aws-sdk-go-v2/service/ec2/types"
	"github.com/aws/aws-sdk-go-v2/service/sts"

	"github.com/your-org/ami-agent-base/internal/awsx"
	cfgpkg "github.com/your-org/ami-agent-base/internal/config"
	"github.com/your-org/ami-agent-base/internal/model"
	"github.com/your-org/ami-agent-base/internal/selector"
)

type App struct {
	Config  cfgpkg.Config
	Factory *awsx.Factory
}

func New(c cfgpkg.Config) *App {
	return &App{Config: c, Factory: awsx.NewFactory(c.AWS.Profile)}
}

type DoctorResult struct {
	Identity        Identity `json:"identity"`
	ConfiguredTypes []string `json:"configured_types"`
	Profile         string   `json:"profile,omitempty"`
}

type Identity struct {
	Account string `json:"account"`
	ARN     string `json:"arn"`
	UserID  string `json:"user_id"`
}

func (a *App) Doctor(ctx context.Context) (DoctorResult, error) {
	var firstRegion string
	for _, name := range a.Config.TypeNames() {
		firstRegion = a.Config.AMITypes[name].SourceRegion
		break
	}
	clients, err := a.Factory.ForRegion(ctx, firstRegion)
	if err != nil {
		return DoctorResult{}, err
	}
	out, err := clients.STS.GetCallerIdentity(ctx, &sts.GetCallerIdentityInput{})
	if err != nil {
		return DoctorResult{}, fmt.Errorf("sts GetCallerIdentity: %w", err)
	}
	return DoctorResult{
		Identity:        Identity{Account: aws.ToString(out.Account), ARN: aws.ToString(out.Arn), UserID: aws.ToString(out.UserId)},
		ConfiguredTypes: a.Config.TypeNames(),
		Profile:         a.Config.AWS.Profile,
	}, nil
}

func (a *App) Latest(ctx context.Context, typeName string) (model.Image, error) {
	t, err := a.Config.Type(typeName)
	if err != nil {
		return model.Image{}, err
	}
	images, err := a.listImages(ctx, t.SourceRegion, t.Owner, t.NamePatterns, []string{"available"})
	if err != nil {
		return model.Image{}, err
	}
	return selector.Latest(images, t.LatestStrategy, t.TimestampRegex)
}

func (a *App) listImages(ctx context.Context, region, owner string, namePatterns, states []string) ([]model.Image, error) {
	clients, err := a.Factory.ForRegion(ctx, region)
	if err != nil {
		return nil, err
	}
	filters := []ec2types.Filter{{Name: aws.String("name"), Values: namePatterns}}
	if len(states) > 0 {
		filters = append(filters, ec2types.Filter{Name: aws.String("state"), Values: states})
	}
	out, err := clients.EC2.DescribeImages(ctx, &ec2.DescribeImagesInput{Owners: []string{owner}, Filters: filters})
	if err != nil {
		return nil, fmt.Errorf("ec2 DescribeImages region=%s owner=%s: %w", region, owner, err)
	}
	images := make([]model.Image, 0, len(out.Images))
	for _, img := range out.Images {
		created, _ := time.Parse(time.RFC3339, aws.ToString(img.CreationDate))
		images = append(images, model.Image{
			ID: aws.ToString(img.ImageId), Name: aws.ToString(img.Name), CreationDate: created, State: string(img.State),
		})
	}
	return images, nil
}

func (a *App) CloneStatuses(ctx context.Context, typeName string, latest model.Image) ([]model.CloneStatus, map[string]string, error) {
	t, err := a.Config.Type(typeName)
	if err != nil {
		return nil, nil, err
	}
	regions := uniqueStrings(t.TargetRegions)
	statuses := make([]model.CloneStatus, 0, len(regions))
	expected := map[string]string{t.SourceRegion: latest.ID}
	for _, region := range regions {
		if region == t.SourceRegion {
			continue
		}
		images, err := a.listImages(ctx, region, "self", []string{latest.Name}, []string{"available", "pending"})
		if err != nil {
			return nil, nil, err
		}
		status := model.CloneStatus{Region: region, SourceAMI: latest.ID, SourceName: latest.Name, Status: "missing", Reason: "no target AMI with the source AMI name"}
		if len(images) > 0 {
			sort.Slice(images, func(i, j int) bool { return images[i].CreationDate.After(images[j].CreationDate) })
			img := images[0]
			status.TargetAMI = img.ID
			status.TargetState = img.State
			if img.State == "available" {
				status.Status = "cloned"
				status.Reason = ""
				expected[region] = img.ID
			} else {
				status.Status = "pending"
				status.Reason = "target AMI exists but is not available yet"
			}
		}
		statuses = append(statuses, status)
	}
	sort.Slice(statuses, func(i, j int) bool { return statuses[i].Region < statuses[j].Region })
	return statuses, expected, nil
}

func (a *App) ASGCompliance(ctx context.Context, typeName string, expectedByRegion map[string]string) ([]model.ASGCompliance, error) {
	t, err := a.Config.Type(typeName)
	if err != nil {
		return nil, err
	}
	var results []model.ASGCompliance
	for _, target := range t.ASGs {
		expectedAMI := expectedByRegion[target.Region]
		if expectedAMI == "" {
			for _, name := range target.Names {
				results = append(results, model.ASGCompliance{Region: target.Region, ASGName: name, Status: "blocked", Reason: "expected AMI is unavailable in this region"})
			}
			continue
		}
		clients, err := a.Factory.ForRegion(ctx, target.Region)
		if err != nil {
			return nil, err
		}
		out, err := clients.AutoScaling.DescribeAutoScalingGroups(ctx, &autoscaling.DescribeAutoScalingGroupsInput{AutoScalingGroupNames: target.Names})
		if err != nil {
			return nil, fmt.Errorf("autoscaling DescribeAutoScalingGroups region=%s: %w", target.Region, err)
		}
		found := make(map[string]bool)
		for _, g := range out.AutoScalingGroups {
			name := aws.ToString(g.AutoScalingGroupName)
			found[name] = true
			item := model.ASGCompliance{Region: target.Region, ASGName: name, ExpectedAMI: expectedAMI}
			if g.MixedInstancesPolicy != nil {
				item.Status = "unsupported"
				item.Reason = "mixed instances policy is intentionally not mutated or inferred by base version"
				results = append(results, item)
				continue
			}
			actualAMI, sourceType, ltID, version, err := a.resolveASGImage(ctx, clients, g)
			if err != nil {
				item.Status = "error"
				item.Reason = err.Error()
				results = append(results, item)
				continue
			}
			item.ActualAMI = actualAMI
			item.LaunchSourceType = sourceType
			item.LaunchTemplateID = ltID
			item.LaunchVersion = version
			item.Compliant = actualAMI == expectedAMI
			if item.Compliant {
				item.Status = "compliant"
			} else {
				item.Status = "non_compliant"
				item.Reason = "ASG launch source does not use expected AMI"
			}
			results = append(results, item)
		}
		for _, name := range target.Names {
			if !found[name] {
				results = append(results, model.ASGCompliance{Region: target.Region, ASGName: name, ExpectedAMI: expectedAMI, Status: "not_found", Reason: "configured ASG was not returned by AWS"})
			}
		}
	}
	sort.Slice(results, func(i, j int) bool {
		if results[i].Region == results[j].Region {
			return results[i].ASGName < results[j].ASGName
		}
		return results[i].Region < results[j].Region
	})
	return results, nil
}

func (a *App) resolveASGImage(ctx context.Context, clients *awsx.RegionalClients, g autotypes.AutoScalingGroup) (string, string, string, string, error) {
	if g.LaunchTemplate != nil {
		lt := g.LaunchTemplate
		version := aws.ToString(lt.Version)
		if version == "" {
			version = "$Default"
		}
		in := &ec2.DescribeLaunchTemplateVersionsInput{Versions: []string{version}}
		if aws.ToString(lt.LaunchTemplateId) != "" {
			in.LaunchTemplateId = lt.LaunchTemplateId
		} else if aws.ToString(lt.LaunchTemplateName) != "" {
			in.LaunchTemplateName = lt.LaunchTemplateName
		} else {
			return "", "launch_template", "", version, fmt.Errorf("launch template has neither id nor name")
		}
		out, err := clients.EC2.DescribeLaunchTemplateVersions(ctx, in)
		if err != nil {
			return "", "launch_template", aws.ToString(lt.LaunchTemplateId), version, fmt.Errorf("ec2 DescribeLaunchTemplateVersions: %w", err)
		}
		if len(out.LaunchTemplateVersions) != 1 || out.LaunchTemplateVersions[0].LaunchTemplateData == nil {
			return "", "launch_template", aws.ToString(lt.LaunchTemplateId), version, fmt.Errorf("unable to resolve exactly one launch template version")
		}
		resolved := out.LaunchTemplateVersions[0]
		resolvedVersion := ""
		if resolved.VersionNumber != nil {
			resolvedVersion = fmt.Sprintf("%d", *resolved.VersionNumber)
		}
		return aws.ToString(resolved.LaunchTemplateData.ImageId), "launch_template", aws.ToString(resolved.LaunchTemplateId), resolvedVersion, nil
	}
	if aws.ToString(g.LaunchConfigurationName) != "" {
		name := aws.ToString(g.LaunchConfigurationName)
		out, err := clients.AutoScaling.DescribeLaunchConfigurations(ctx, &autoscaling.DescribeLaunchConfigurationsInput{LaunchConfigurationNames: []string{name}})
		if err != nil {
			return "", "launch_configuration", "", "", fmt.Errorf("autoscaling DescribeLaunchConfigurations: %w", err)
		}
		if len(out.LaunchConfigurations) != 1 {
			return "", "launch_configuration", "", "", fmt.Errorf("unable to resolve launch configuration %s", name)
		}
		return aws.ToString(out.LaunchConfigurations[0].ImageId), "launch_configuration", "", "", nil
	}
	return "", "unknown", "", "", fmt.Errorf("ASG has no direct launch template or launch configuration")
}

func (a *App) Check(ctx context.Context, typeName string) (model.CheckResult, error) {
	t, err := a.Config.Type(typeName)
	if err != nil {
		return model.CheckResult{}, err
	}
	latest, err := a.Latest(ctx, typeName)
	if err != nil {
		return model.CheckResult{}, err
	}
	clones, expected, err := a.CloneStatuses(ctx, typeName, latest)
	if err != nil {
		return model.CheckResult{}, err
	}
	asgs, err := a.ASGCompliance(ctx, typeName, expected)
	if err != nil {
		return model.CheckResult{}, err
	}
	result := model.CheckResult{AMIType: typeName, SourceRegion: t.SourceRegion, Latest: latest, Clones: clones, ASGs: asgs, Healthy: true}
	for _, c := range clones {
		switch c.Status {
		case "missing":
			result.Summary.MissingClones++
			result.Healthy = false
			result.ChangeNeeded = true
		case "pending":
			result.Summary.PendingClones++
			result.Healthy = false
		}
	}
	for _, g := range asgs {
		switch g.Status {
		case "non_compliant", "blocked", "not_found", "error":
			result.Summary.NonCompliantASGs++
			result.Healthy = false
			result.ChangeNeeded = true
		case "unsupported":
			result.Summary.UnsupportedASGs++
			result.Healthy = false
			result.ChangeNeeded = true
		}
	}
	return result, nil
}

func (a *App) Reconcile(ctx context.Context, typeName string, apply bool) (model.ReconcileResult, error) {
	check, err := a.Check(ctx, typeName)
	if err != nil {
		return model.ReconcileResult{}, err
	}
	result := model.ReconcileResult{AMIType: typeName, Mode: "plan"}
	if apply {
		result.Mode = "apply"
	}
	for _, c := range check.Clones {
		if c.Status != "missing" {
			continue
		}
		action := model.ReconcileAction{Action: "copy_ami", Region: c.Region, SourceRegion: check.SourceRegion, SourceAMI: check.Latest.ID, SourceName: check.Latest.Name, Status: "planned"}
		if apply {
			clients, err := a.Factory.ForRegion(ctx, c.Region)
			if err != nil {
				return result, err
			}
			desc := fmt.Sprintf("Copied by amiops from %s/%s", check.SourceRegion, check.Latest.ID)
			out, err := clients.EC2.CopyImage(ctx, &ec2.CopyImageInput{SourceImageId: aws.String(check.Latest.ID), SourceRegion: aws.String(check.SourceRegion), Name: aws.String(check.Latest.Name), Description: aws.String(desc)})
			if err != nil {
				action.Status = "failed"
				action.Reason = err.Error()
				result.Actions = append(result.Actions, action)
				continue
			}
			action.Status = "submitted"
			action.TargetAMI = aws.ToString(out.ImageId)
		}
		result.Actions = append(result.Actions, action)
	}
	for _, g := range check.ASGs {
		if g.Status == "compliant" {
			continue
		}
		result.Actions = append(result.Actions, model.ReconcileAction{
			Action:    "asg_remediation_not_supported_in_v0_1",
			Region:    g.Region,
			TargetAMI: g.ExpectedAMI,
			Status:    "manual_review",
			Reason:    fmt.Sprintf("ASG %s status=%s; base version intentionally does not mutate ASGs", g.ASGName, g.Status),
		})
	}
	return result, nil
}

func uniqueStrings(in []string) []string {
	seen := make(map[string]struct{}, len(in))
	out := make([]string, 0, len(in))
	for _, s := range in {
		if _, ok := seen[s]; ok {
			continue
		}
		seen[s] = struct{}{}
		out = append(out, s)
	}
	sort.Strings(out)
	return out
}
