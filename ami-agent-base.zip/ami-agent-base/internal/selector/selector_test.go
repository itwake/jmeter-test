package selector

import (
	"testing"
	"time"

	"github.com/your-org/ami-agent-base/internal/model"
)

func TestLatestPrefersNameTimestamp(t *testing.T) {
	images := []model.Image{
		{ID: "ami-old", Name: "gfx-haproxy-20260801120000", CreationDate: mustTime("2026-08-15T00:00:00Z")},
		{ID: "ami-new", Name: "gfx-haproxy-20260818120000", CreationDate: mustTime("2026-08-14T00:00:00Z")},
	}
	got, err := Latest(images, "name_timestamp_then_creation_date", `(\d{14})$`)
	if err != nil {
		t.Fatal(err)
	}
	if got.ID != "ami-new" {
		t.Fatalf("expected ami-new, got %s", got.ID)
	}
}

func TestLatestFallsBackToCreationDate(t *testing.T) {
	images := []model.Image{
		{ID: "ami-a", Name: "no-timestamp-a", CreationDate: mustTime("2026-08-10T00:00:00Z")},
		{ID: "ami-b", Name: "no-timestamp-b", CreationDate: mustTime("2026-08-11T00:00:00Z")},
	}
	got, err := Latest(images, "name_timestamp_then_creation_date", `(\d{14})$`)
	if err != nil {
		t.Fatal(err)
	}
	if got.ID != "ami-b" {
		t.Fatalf("expected ami-b, got %s", got.ID)
	}
}

func mustTime(v string) time.Time {
	t, err := time.Parse(time.RFC3339, v)
	if err != nil {
		panic(err)
	}
	return t
}
