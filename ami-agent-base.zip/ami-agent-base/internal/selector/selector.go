package selector

import (
	"fmt"
	"regexp"
	"sort"
	"time"

	"github.com/your-org/ami-agent-base/internal/model"
)

func Latest(images []model.Image, strategy, timestampPattern string) (model.Image, error) {
	if len(images) == 0 {
		return model.Image{}, fmt.Errorf("no AMI candidates")
	}
	if strategy != "name_timestamp_then_creation_date" && strategy != "creation_date" {
		return model.Image{}, fmt.Errorf("unsupported latest_strategy %q", strategy)
	}

	var re *regexp.Regexp
	var err error
	if strategy == "name_timestamp_then_creation_date" {
		re, err = regexp.Compile(timestampPattern)
		if err != nil {
			return model.Image{}, fmt.Errorf("invalid timestamp_regex: %w", err)
		}
	}

	copyOf := append([]model.Image(nil), images...)
	sort.SliceStable(copyOf, func(i, j int) bool {
		a, b := copyOf[i], copyOf[j]
		ak, aHas := effectiveTime(a, strategy, re)
		bk, bHas := effectiveTime(b, strategy, re)
		if aHas != bHas {
			return aHas
		}
		if !ak.Equal(bk) {
			return ak.After(bk)
		}
		if !a.CreationDate.Equal(b.CreationDate) {
			return a.CreationDate.After(b.CreationDate)
		}
		if a.Name != b.Name {
			return a.Name > b.Name
		}
		return a.ID > b.ID
	})
	return copyOf[0], nil
}

func effectiveTime(img model.Image, strategy string, re *regexp.Regexp) (time.Time, bool) {
	if strategy == "creation_date" {
		return img.CreationDate, !img.CreationDate.IsZero()
	}
	if re != nil {
		m := re.FindStringSubmatch(img.Name)
		if len(m) >= 2 {
			if t, err := time.ParseInLocation("20060102150405", m[1], time.UTC); err == nil {
				return t, true
			}
		}
	}
	return img.CreationDate, !img.CreationDate.IsZero()
}
