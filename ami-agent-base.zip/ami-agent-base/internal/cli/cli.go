package cli

import (
	"context"
	"errors"
	"flag"
	"fmt"
	"io"
	"strings"
	"time"

	"github.com/your-org/ami-agent-base/internal/app"
	cfgpkg "github.com/your-org/ami-agent-base/internal/config"
	"github.com/your-org/ami-agent-base/internal/output"
)

const version = "0.1.0"

type Runner struct {
	Stdout io.Writer
	Stderr io.Writer
}

type commonFlags struct {
	configPath string
	pretty     bool
}

func (r Runner) Run(args []string) int {
	command := strings.Join(args, " ")
	if command == "" {
		command = "help"
	}
	pretty := false
	data, appErr := r.dispatch(args, &pretty)
	if appErr != nil {
		_ = output.WriteError(r.Stdout, commandName(args), appErr, pretty)
		if appErr.ExitCode == 0 {
			return 1
		}
		return appErr.ExitCode
	}
	if err := output.WriteSuccess(r.Stdout, commandName(args), data, pretty); err != nil {
		fmt.Fprintln(r.Stderr, err)
		return 1
	}
	return 0
}

func (r Runner) dispatch(args []string, pretty *bool) (any, *output.AppError) {
	if len(args) == 0 || args[0] == "help" || args[0] == "--help" || args[0] == "-h" {
		return helpData(), nil
	}
	switch args[0] {
	case "version":
		return map[string]any{"version": version}, nil
	case "capabilities":
		fs := flag.NewFlagSet("capabilities", flag.ContinueOnError)
		fs.SetOutput(io.Discard)
		fs.BoolVar(pretty, "pretty", false, "pretty JSON")
		if err := fs.Parse(args[1:]); err != nil {
			return nil, usageErr(err)
		}
		return capabilitiesData(), nil
	case "doctor":
		return r.runDoctor(args[1:], pretty)
	case "check":
		return r.runCheck(args[1:], pretty)
	case "reconcile":
		return r.runReconcile(args[1:], pretty)
	case "ami":
		return r.runAMI(args[1:], pretty)
	case "asg":
		return r.runASG(args[1:], pretty)
	default:
		return nil, output.NewError("UNKNOWN_COMMAND", "unknown command; use amiops capabilities", false, 2)
	}
}

func (r Runner) runDoctor(args []string, pretty *bool) (any, *output.AppError) {
	fs, c := newCommonFlagSet("doctor", pretty)
	if err := fs.Parse(args); err != nil {
		return nil, usageErr(err)
	}
	a, ctx, cancel, e := loadApp(c)
	if e != nil {
		return nil, e
	}
	defer cancel()
	v, err := a.Doctor(ctx)
	if err != nil {
		return nil, awsErr("DOCTOR_FAILED", err)
	}
	return v, nil
}

func (r Runner) runCheck(args []string, pretty *bool) (any, *output.AppError) {
	fs, c := newCommonFlagSet("check", pretty)
	typeName := fs.String("type", "", "configured AMI type")
	if err := fs.Parse(args); err != nil {
		return nil, usageErr(err)
	}
	if *typeName == "" {
		return nil, output.NewError("TYPE_REQUIRED", "--type is required", false, 2)
	}
	a, ctx, cancel, e := loadApp(c)
	if e != nil {
		return nil, e
	}
	defer cancel()
	v, err := a.Check(ctx, *typeName)
	if err != nil {
		return nil, awsErr("CHECK_FAILED", err)
	}
	return v, nil
}

func (r Runner) runReconcile(args []string, pretty *bool) (any, *output.AppError) {
	fs, c := newCommonFlagSet("reconcile", pretty)
	typeName := fs.String("type", "", "configured AMI type")
	apply := fs.Bool("apply", false, "execute supported changes; default is plan only")
	if err := fs.Parse(args); err != nil {
		return nil, usageErr(err)
	}
	if *typeName == "" {
		return nil, output.NewError("TYPE_REQUIRED", "--type is required", false, 2)
	}
	a, ctx, cancel, e := loadApp(c)
	if e != nil {
		return nil, e
	}
	defer cancel()
	v, err := a.Reconcile(ctx, *typeName, *apply)
	if err != nil {
		return nil, awsErr("RECONCILE_FAILED", err)
	}
	return v, nil
}

func (r Runner) runAMI(args []string, pretty *bool) (any, *output.AppError) {
	if len(args) == 0 {
		return nil, output.NewError("AMI_SUBCOMMAND_REQUIRED", "use: amiops ami latest|clone-status", false, 2)
	}
	switch args[0] {
	case "latest":
		fs, c := newCommonFlagSet("ami latest", pretty)
		typeName := fs.String("type", "", "configured AMI type")
		if err := fs.Parse(args[1:]); err != nil {
			return nil, usageErr(err)
		}
		if *typeName == "" {
			return nil, output.NewError("TYPE_REQUIRED", "--type is required", false, 2)
		}
		a, ctx, cancel, e := loadApp(c)
		if e != nil {
			return nil, e
		}
		defer cancel()
		v, err := a.Latest(ctx, *typeName)
		if err != nil {
			return nil, awsErr("AMI_LATEST_FAILED", err)
		}
		return v, nil
	case "clone-status":
		fs, c := newCommonFlagSet("ami clone-status", pretty)
		typeName := fs.String("type", "", "configured AMI type")
		if err := fs.Parse(args[1:]); err != nil {
			return nil, usageErr(err)
		}
		if *typeName == "" {
			return nil, output.NewError("TYPE_REQUIRED", "--type is required", false, 2)
		}
		a, ctx, cancel, e := loadApp(c)
		if e != nil {
			return nil, e
		}
		defer cancel()
		latest, err := a.Latest(ctx, *typeName)
		if err != nil {
			return nil, awsErr("AMI_LATEST_FAILED", err)
		}
		v, _, err := a.CloneStatuses(ctx, *typeName, latest)
		if err != nil {
			return nil, awsErr("AMI_CLONE_STATUS_FAILED", err)
		}
		return map[string]any{"latest": latest, "clones": v}, nil
	default:
		return nil, output.NewError("UNKNOWN_AMI_SUBCOMMAND", "use: amiops ami latest|clone-status", false, 2)
	}
}

func (r Runner) runASG(args []string, pretty *bool) (any, *output.AppError) {
	if len(args) == 0 || args[0] != "compliance" {
		return nil, output.NewError("UNKNOWN_ASG_SUBCOMMAND", "use: amiops asg compliance", false, 2)
	}
	fs, c := newCommonFlagSet("asg compliance", pretty)
	typeName := fs.String("type", "", "configured AMI type")
	if err := fs.Parse(args[1:]); err != nil {
		return nil, usageErr(err)
	}
	if *typeName == "" {
		return nil, output.NewError("TYPE_REQUIRED", "--type is required", false, 2)
	}
	a, ctx, cancel, e := loadApp(c)
	if e != nil {
		return nil, e
	}
	defer cancel()
	latest, err := a.Latest(ctx, *typeName)
	if err != nil {
		return nil, awsErr("AMI_LATEST_FAILED", err)
	}
	_, expected, err := a.CloneStatuses(ctx, *typeName, latest)
	if err != nil {
		return nil, awsErr("AMI_CLONE_STATUS_FAILED", err)
	}
	v, err := a.ASGCompliance(ctx, *typeName, expected)
	if err != nil {
		return nil, awsErr("ASG_COMPLIANCE_FAILED", err)
	}
	return map[string]any{"latest": latest, "asgs": v}, nil
}

func newCommonFlagSet(name string, pretty *bool) (*flag.FlagSet, commonFlags) {
	fs := flag.NewFlagSet(name, flag.ContinueOnError)
	fs.SetOutput(io.Discard)
	var c commonFlags
	fs.StringVar(&c.configPath, "config", "config.json", "path to configuration")
	fs.BoolVar(pretty, "pretty", false, "pretty JSON")
	return fs, c
}

func loadApp(c commonFlags) (*app.App, context.Context, context.CancelFunc, *output.AppError) {
	cfg, err := cfgpkg.Load(c.configPath)
	if err != nil {
		return nil, nil, nil, output.NewError("CONFIG_INVALID", err.Error(), false, 2)
	}
	timeout := time.Duration(cfg.AWS.TimeoutSeconds) * time.Second
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	return app.New(cfg), ctx, cancel, nil
}

func usageErr(err error) *output.AppError {
	return output.NewError("INVALID_ARGUMENT", err.Error(), false, 2)
}

func awsErr(code string, err error) *output.AppError {
	retryable := errors.Is(err, context.DeadlineExceeded) || strings.Contains(strings.ToLower(err.Error()), "timeout") || strings.Contains(strings.ToLower(err.Error()), "throttl")
	return output.NewError(code, err.Error(), retryable, 1)
}

func commandName(args []string) string {
	if len(args) == 0 {
		return "help"
	}
	if len(args) >= 2 && (args[0] == "ami" || args[0] == "asg") {
		return args[0] + " " + args[1]
	}
	return args[0]
}

func helpData() map[string]any {
	return map[string]any{
		"usage": "amiops <command> [flags]",
		"recommended": []string{
			"amiops doctor --config config.json",
			"amiops check --config config.json --type haproxy",
			"amiops reconcile --config config.json --type haproxy",
			"amiops reconcile --config config.json --type haproxy --apply",
		},
	}
}

func capabilitiesData() map[string]any {
	return map[string]any{
		"tool":    "amiops",
		"version": version,
		"output":  "JSON only; compact by default; use --pretty for humans",
		"commands": []map[string]any{
			{"name": "doctor", "read_only": true, "purpose": "validate config and AWS identity"},
			{"name": "check", "read_only": true, "purpose": "one-shot AMI + clone + ASG maintenance assessment"},
			{"name": "ami latest", "read_only": true, "purpose": "deterministically select latest source AMI"},
			{"name": "ami clone-status", "read_only": true, "purpose": "check target-region clones"},
			{"name": "asg compliance", "read_only": true, "purpose": "compare ASG launch AMI with expected AMI"},
			{"name": "reconcile", "read_only": true, "purpose": "plan supported changes"},
			{"name": "reconcile --apply", "read_only": false, "purpose": "copy missing AMIs only in base version"},
		},
		"guardrails": []string{
			"No delete/deregister operation exists",
			"No ASG mutation exists in base version",
			"MixedInstancesPolicy is reported as unsupported instead of guessed",
			"All operational decisions are returned as structured JSON",
		},
	}
}
