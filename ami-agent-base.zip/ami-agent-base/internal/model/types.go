package model

import "time"

type Image struct {
	ID           string    `json:"image_id"`
	Name         string    `json:"name"`
	CreationDate time.Time `json:"creation_date"`
	State        string    `json:"state"`
}

type CloneStatus struct {
	Region      string `json:"region"`
	Status      string `json:"status"`
	SourceAMI   string `json:"source_ami"`
	SourceName  string `json:"source_name"`
	TargetAMI   string `json:"target_ami,omitempty"`
	TargetState string `json:"target_state,omitempty"`
	Reason      string `json:"reason,omitempty"`
}

type ASGCompliance struct {
	Region           string `json:"region"`
	ASGName          string `json:"asg_name"`
	Status           string `json:"status"`
	Compliant        bool   `json:"compliant"`
	ExpectedAMI      string `json:"expected_ami,omitempty"`
	ActualAMI        string `json:"actual_ami,omitempty"`
	LaunchSourceType string `json:"launch_source_type,omitempty"`
	LaunchTemplateID string `json:"launch_template_id,omitempty"`
	LaunchVersion    string `json:"launch_version,omitempty"`
	Reason           string `json:"reason,omitempty"`
}

type CheckResult struct {
	AMIType      string          `json:"ami_type"`
	SourceRegion string          `json:"source_region"`
	Latest       Image           `json:"latest"`
	Clones       []CloneStatus   `json:"clones"`
	ASGs         []ASGCompliance `json:"asgs"`
	Healthy      bool            `json:"healthy"`
	ChangeNeeded bool            `json:"change_needed"`
	Summary      CheckSummary    `json:"summary"`
}

type CheckSummary struct {
	MissingClones    int `json:"missing_clones"`
	PendingClones    int `json:"pending_clones"`
	NonCompliantASGs int `json:"non_compliant_asgs"`
	UnsupportedASGs  int `json:"unsupported_asgs"`
}

type ReconcileAction struct {
	Action       string `json:"action"`
	Region       string `json:"region"`
	SourceRegion string `json:"source_region,omitempty"`
	SourceAMI    string `json:"source_ami,omitempty"`
	SourceName   string `json:"source_name,omitempty"`
	TargetAMI    string `json:"target_ami,omitempty"`
	Status       string `json:"status"`
	Reason       string `json:"reason,omitempty"`
}

type ReconcileResult struct {
	AMIType string            `json:"ami_type"`
	Mode    string            `json:"mode"`
	Actions []ReconcileAction `json:"actions"`
}
