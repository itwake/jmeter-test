package config

import (
	"encoding/json"
	"fmt"
	"os"
	"sort"
	"strings"
)

type Config struct {
	SchemaVersion int                      `json:"schema_version"`
	AWS           AWSConfig                `json:"aws"`
	AMITypes      map[string]AMITypeConfig `json:"ami_types"`
}

type AWSConfig struct {
	Profile        string `json:"profile"`
	TimeoutSeconds int    `json:"timeout_seconds"`
}

type AMITypeConfig struct {
	SourceRegion   string      `json:"source_region"`
	Owner          string      `json:"owner"`
	NamePatterns   []string    `json:"name_patterns"`
	LatestStrategy string      `json:"latest_strategy"`
	TimestampRegex string      `json:"timestamp_regex"`
	TargetRegions  []string    `json:"target_regions"`
	ASGs           []ASGTarget `json:"asgs"`
}

type ASGTarget struct {
	Region string   `json:"region"`
	Names  []string `json:"names"`
}

func Load(path string) (Config, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return Config{}, fmt.Errorf("read config: %w", err)
	}
	var c Config
	if err := json.Unmarshal(b, &c); err != nil {
		return Config{}, fmt.Errorf("parse config: %w", err)
	}
	if err := c.Validate(); err != nil {
		return Config{}, err
	}
	return c, nil
}

func (c *Config) Validate() error {
	if c.SchemaVersion != 1 {
		return fmt.Errorf("unsupported schema_version %d; expected 1", c.SchemaVersion)
	}
	if c.AWS.TimeoutSeconds <= 0 {
		c.AWS.TimeoutSeconds = 30
	}
	if len(c.AMITypes) == 0 {
		return fmt.Errorf("ami_types must not be empty")
	}
	for name, t := range c.AMITypes {
		if strings.TrimSpace(name) == "" {
			return fmt.Errorf("ami type name must not be empty")
		}
		if t.SourceRegion == "" {
			return fmt.Errorf("ami_types.%s.source_region is required", name)
		}
		if t.Owner == "" {
			return fmt.Errorf("ami_types.%s.owner is required", name)
		}
		if len(t.NamePatterns) == 0 {
			return fmt.Errorf("ami_types.%s.name_patterns must not be empty", name)
		}
		if t.LatestStrategy == "" {
			t.LatestStrategy = "name_timestamp_then_creation_date"
		}
		if t.TimestampRegex == "" {
			t.TimestampRegex = `(\d{14})$`
		}
		c.AMITypes[name] = t
	}
	return nil
}

func (c Config) Type(name string) (AMITypeConfig, error) {
	t, ok := c.AMITypes[name]
	if !ok {
		return AMITypeConfig{}, fmt.Errorf("unknown ami type %q; configured types: %s", name, strings.Join(c.TypeNames(), ", "))
	}
	return t, nil
}

func (c Config) TypeNames() []string {
	names := make([]string, 0, len(c.AMITypes))
	for name := range c.AMITypes {
		names = append(names, name)
	}
	sort.Strings(names)
	return names
}
