# AMI Maintenance Agent Contract

This workspace uses one deterministic executable, `amiops`, for AWS AMI maintenance.

## Non-negotiable rules

1. Do not write ad-hoc AWS CLI, Bash, PowerShell, Python, or custom Go commands for operations already supported by `amiops`.
2. Start a session with `amiops doctor --config <path>` if environment/credential status is unknown.
3. For routine AMI maintenance, prefer exactly one command:
   `amiops check --config <path> --type <ami-type>`
4. If a change is needed, first run:
   `amiops reconcile --config <path> --type <ami-type>`
   This is dry-run/plan mode.
5. Only after change approval, run:
   `amiops reconcile --config <path> --type <ami-type> --apply`
6. `reconcile --apply` in this base version ONLY copies missing AMIs. It does not update ASGs, replace instances, deregister AMIs, or delete resources.
7. Treat the executable JSON as the source of truth. Do not infer success from terminal prose.
8. If a command is unknown, run `amiops capabilities`; do not invent a new command.
9. If `ok=false`, use `error.code` and `error.message`. Do not blindly retry non-retryable errors.
10. Do not reproduce the AMI selection rules in the prompt. `amiops` owns deterministic AMI selection.

## Normal loop

User intent -> `amiops check` -> explain result -> if change needed `amiops reconcile` -> request/verify approval -> `amiops reconcile --apply` -> `amiops check` again.
