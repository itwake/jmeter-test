# AMI Agent Base (Go-only operational runtime)

A small, deterministic AWS AMI maintenance runtime designed to be called by a VS Code agent.

The design goal is not to let the agent invent shell commands. The agent should make high-level decisions and call a stable Go executable with a small command surface.

## Core model

```text
VS Code Agent
    |
    | fixed commands only
    v
  amiops
    |
    | AWS SDK for Go v2
    v
   AWS
    |
    v
structured JSON
```

All executable source code in this repository is Go. There are no Bash, PowerShell, Python, or Node helper scripts.

## v0.1 scope

### Read-only

- `doctor` - validate configuration and AWS identity.
- `check` - one high-level maintenance check:
  - select latest source AMI;
  - check target-region AMI copies;
  - resolve configured ASG launch AMIs;
  - compare ASGs with the expected AMI.
- `ami latest` - deterministic AMI selection.
- `ami clone-status` - target-region clone status.
- `asg compliance` - ASG-to-AMI compliance.
- `capabilities` - self-describing command contract for the agent.

### Write

- `reconcile` - dry-run by default.
- `reconcile --apply` - **only copies missing AMIs** in v0.1.

There is deliberately no delete/deregister operation and no ASG mutation in this base version.

## Why `check` is the normal Agent command

Instead of making the agent execute and reason over several low-level commands, its normal maintenance path is one command:

```text
amiops check --config config.json --type haproxy
```

The result contains the latest AMI, clone states, ASG states, a summary, and `change_needed`.

A typical Agent loop therefore becomes:

```text
check -> explain -> reconcile(dry-run) -> approval -> reconcile --apply -> check
```

This keeps prompts smaller and removes repeated AWS command construction from the model.

## Configuration

Copy `config.example.json` to `config.json` and edit it for the environment.

Important fields:

- `source_region`: where the upstream/base AMI is discovered.
- `owner`: allowed owner account for the source AMI.
- `name_patterns`: AWS EC2 image name filters.
- `latest_strategy`: currently `name_timestamp_then_creation_date` or `creation_date`.
- `timestamp_regex`: capture a 14-digit timestamp such as `20260818113022` from the AMI name.
- `target_regions`: regions where the latest AMI must exist.
- `asgs`: ASGs that should use that region's expected AMI.

The default example includes `haproxy`, `batch-controller`, and `eks` placeholders. Replace patterns, regions, and ASG names with real values.

## AWS credentials

`amiops` uses the AWS SDK for Go v2 default configuration chain. If `aws.profile` is non-empty, that shared AWS profile is selected explicitly. Otherwise normal SDK credential/config discovery is used.

No AWS CLI executable is required by `amiops`.

## Build from source

Requirements for the build machine:

- Go 1.23+
- access to the Go module proxy or an internal Go dependency mirror

First resolve dependencies:

```text
go mod tidy
```

Build for the current machine:

```text
go run ./tools/build
```

Build distributable binaries for Windows/macOS/Linux, amd64/arm64:

```text
go run ./tools/build -all
```

Output goes to `dist/`:

```text
dist/
  amiops-windows-amd64.exe
  amiops-windows-arm64.exe
  amiops-darwin-amd64
  amiops-darwin-arm64
  amiops-linux-amd64
  amiops-linux-arm64
```

End users only need the matching `amiops` binary plus configuration. They do not need Go installed.

## Agent usage

The agent contract is in `AGENT.md` and mirrored by `.github/copilot-instructions.md`.

Recommended first checks:

```text
amiops capabilities --pretty
amiops doctor --config config.json --pretty
amiops check --config config.json --type haproxy --pretty
```

For normal Agent execution, omit `--pretty` to get compact JSON and reduce tokens.

### Dry-run a repair

```text
amiops reconcile --config config.json --type haproxy
```

Example shape:

```json
{"ok":true,"command":"reconcile","data":{"ami_type":"haproxy","mode":"plan","actions":[{"action":"copy_ami","region":"ap-southeast-1","source_region":"ap-east-1","source_ami":"ami-123","source_name":"gfx-haproxy-20260818113022","status":"planned"}]}}
```

### Apply supported repair

```text
amiops reconcile --config config.json --type haproxy --apply
```

The base version submits the missing `CopyImage` operation and returns the new target AMI ID. A subsequent `check` will normally show `pending` until AWS marks the AMI `available`.

## Output contract

Success:

```json
{
  "ok": true,
  "command": "check",
  "timestamp": "2026-08-18T01:30:00Z",
  "data": {}
}
```

Error:

```json
{
  "ok": false,
  "command": "check",
  "timestamp": "2026-08-18T01:30:00Z",
  "error": {
    "code": "CHECK_FAILED",
    "message": "...",
    "retryable": false
  }
}
```

The Agent should branch on `ok`, `error.code`, domain statuses, and `change_needed` rather than parsing prose.

## AMI selection rule

`name_timestamp_then_creation_date` is intentionally deterministic:

1. Match source images by configured owner + name filters + `available` state.
2. Extract a `YYYYMMDDhhmmss` timestamp from the AMI name with `timestamp_regex` when possible.
3. Prefer the newest extracted timestamp.
4. Fall back to AWS `CreationDate` if a timestamp is absent.
5. Use deterministic name/AMI-ID tie breakers.

This rule lives in Go and has unit tests. It should not be reimplemented by the Agent prompt.

## ASG support in v0.1

The read-only compliance check supports:

- direct Launch Template based ASGs;
- legacy Launch Configuration based ASGs.

`MixedInstancesPolicy` is intentionally returned as `unsupported` in v0.1 rather than guessed. That is a safety boundary for the base version.

## Recommended next extension

Keep the Agent commands unchanged and extend `reconcile` internally in Go:

1. Create a new Launch Template version inheriting the current version but replacing `ImageId`.
2. Update the ASG to the new explicit Launch Template version.
3. Optionally start Instance Refresh as a separate policy-controlled action.
4. Add post-update EC2/CloudWatch health checks.

This preserves the stable Agent contract:

```text
check -> reconcile -> apply -> verify
```

while moving more deterministic maintenance logic into the Go executable over time.
