# Validation Notes

Validation performed in the generation environment:

- All Go files passed `gofmt` parsing/formatting.
- Pure-Go packages compiled and tested:
  - `internal/config`
  - `internal/selector`
  - `internal/output`
- `internal/selector` unit tests passed.

The generation environment blocks outbound access to `proxy.golang.org`, so the AWS SDK modules could not be downloaded and a full linked build of `cmd/amiops` could not be executed here.

On a build machine with access to a Go module proxy/internal mirror, run:

```text
go mod tidy
go test ./...
go run ./tools/build -all
```

The AWS integration follows AWS SDK for Go v2 APIs and is intentionally isolated under `internal/awsx` and `internal/app`.
