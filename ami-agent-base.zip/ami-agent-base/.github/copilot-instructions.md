# Workspace instructions

For AWS AMI maintenance, follow `AGENT.md`.

Use the bundled `amiops` executable as the only operational interface. Avoid ad-hoc shell/AWS CLI commands for supported operations. Prefer `check` for observation and `reconcile` for changes.
