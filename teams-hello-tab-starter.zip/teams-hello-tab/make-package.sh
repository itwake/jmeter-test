#!/usr/bin/env bash
set -euo pipefail
if [ $# -lt 1 ]; then echo "Usage: ./make-package.sh https://your-public-url"; exit 1; fi
python3 make_package.py "$1"
