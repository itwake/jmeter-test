# Hello Teams Test — 最小 Microsoft Teams 个人 Tab 应用

这是一个最小 Teams 自定义 app 测试项目。效果很简单：安装后在 Teams 里打开一个个人 Tab，显示 **Hello Teams!**，并尝试用 TeamsJS 读取 Teams 上下文。

## 文件说明

- `public/index.html`：真正显示在 Teams 里的页面。
- `start_server.py`：本地启动一个很小的 HTTP 服务，默认端口 `3978`。
- `make_package.py`：把你的公网 HTTPS tunnel URL 写进 `manifest.json`，并生成可上传的 Teams app `.zip`。
- `appPackage/color.png` 和 `appPackage/outline.png`：Teams app 图标。
- `manifest/manifest.template.json`：Teams manifest 模板。

## 最短测试步骤

### 1. 启动本地页面

macOS / Linux：

```bash
python3 start_server.py
```

Windows：

```powershell
py -3 start_server.py
```

浏览器打开：

```text
http://localhost:3978/index.html
```

能看到 Hello Teams 页面即可。

### 2. 暴露成公网 HTTPS

Teams tab 的 `contentUrl` 需要 Teams 能通过 HTTPS 访问。最简单的本地测试方式之一是 Cloudflare Quick Tunnel：

```bash
cloudflared tunnel --url http://localhost:3978
```

它会输出一个类似下面的 URL：

```text
https://abc-def-123.trycloudflare.com
```

复制这个 `https://...trycloudflare.com` URL。

### 3. 生成 Teams app 上传包

macOS / Linux：

```bash
python3 make_package.py https://abc-def-123.trycloudflare.com
```

Windows：

```powershell
py -3 make_package.py https://abc-def-123.trycloudflare.com
```

生成的文件是：

```text
appPackage/teams-hello-personal-tab.zip
```

### 4. 上传到 Teams

Teams 里进入：

```text
Apps → Manage your apps → Upload an app → Upload a custom app
```

选择：

```text
appPackage/teams-hello-personal-tab.zip
```

安装后打开 **Hello Teams Test**，应该能看到 Hello Teams 页面。

## 常见问题

### 看不到 Upload a custom app

你的 Teams 租户没有允许自定义 app 上传。需要管理员开启 Teams custom app upload / sideloading 权限。

### Teams 里提示 There was a problem reaching this app

优先检查这几项：

1. `start_server.py` 终端还开着。
2. `cloudflared tunnel` 终端还开着。
3. 你运行 `make_package.py` 时填的是最新的 `https://...trycloudflare.com` 地址。
4. 上传的是 `appPackage/teams-hello-personal-tab.zip`，不是整个项目 zip。
5. 如果换了 tunnel URL，请重新运行 `make_package.py` 并重新上传。脚本默认每次生成新的 app id，避免 Teams 缓存旧地址。

### 我想改页面内容

改 `public/index.html`，然后刷新 Teams 里的 Tab。由于本地服务设置了 no-cache，通常刷新后能看到变化。

### 我想部署到正式环境

把 `public/` 目录部署到任意 HTTPS 静态网站服务，比如 Azure Static Web Apps、Azure App Service、GitHub Pages、Cloudflare Pages 等。然后用正式 URL 重新运行：

```bash
python3 make_package.py https://your-real-domain.example.com
```

