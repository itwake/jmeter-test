#!/usr/bin/env python3
"""Start a tiny local web server for the Teams personal-tab test page."""
from __future__ import annotations

import argparse
import functools
import http.server
import os
import socketserver
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PUBLIC = ROOT / "public"

class Handler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self) -> None:
        # Keep local testing simple and avoid stale Teams iframe content while iterating.
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.send_header("Pragma", "no-cache")
        super().end_headers()

    def log_message(self, format: str, *args) -> None:  # noqa: A002
        print(f"[local-server] {self.address_string()} - {format % args}")

class ReuseTCPServer(socketserver.TCPServer):
    allow_reuse_address = True


def main() -> None:
    parser = argparse.ArgumentParser(description="Serve the Teams tab test page over localhost.")
    parser.add_argument("--port", type=int, default=int(os.getenv("PORT", "3978")))
    args = parser.parse_args()

    if not PUBLIC.exists():
        raise SystemExit(f"Missing public folder: {PUBLIC}")

    handler = functools.partial(Handler, directory=str(PUBLIC))
    with ReuseTCPServer(("127.0.0.1", args.port), handler) as httpd:
        print(f"Serving: http://localhost:{args.port}/index.html")
        print("Keep this terminal open while testing in Teams.")
        httpd.serve_forever()

if __name__ == "__main__":
    main()
