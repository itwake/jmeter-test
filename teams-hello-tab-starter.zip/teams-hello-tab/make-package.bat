@echo off
if "%1"=="" (
  echo Usage: make-package.bat https://your-public-url
  exit /b 1
)
py -3 make_package.py %1
