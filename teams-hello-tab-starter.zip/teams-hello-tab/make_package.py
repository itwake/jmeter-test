#!/usr/bin/env python3
"""Generate a Microsoft Teams app package ZIP for a personal static tab."""
from __future__ import annotations

import argparse
import json
import re
import sys
import uuid
import zipfile
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent
APP_PACKAGE = ROOT / "appPackage"
TEMPLATE_PATH = ROOT / "manifest" / "manifest.template.json"
OUTPUT_ZIP = APP_PACKAGE / "teams-hello-personal-tab.zip"


def normalize_base_url(raw: str) -> tuple[str, str]:
    raw = raw.strip().rstrip("/")
    parsed = urlparse(raw)
    if parsed.scheme != "https" or not parsed.netloc:
        raise ValueError("URL 必须是 https:// 开头，例如 https://abc.trycloudflare.com")
    if parsed.username or parsed.password:
        raise ValueError("URL 不能包含用户名或密码")
    host = parsed.hostname
    if not host:
        raise ValueError("无法从 URL 里解析域名")
    # Preserve path only if the user really supplied one. Most tunnel URLs have no path.
    base = f"{parsed.scheme}://{parsed.netloc}{parsed.path.rstrip('/')}"
    if not re.match(r"^[A-Za-z0-9.-]+$", host):
        raise ValueError(f"域名看起来不合法: {host}")
    return base, host


def build_manifest(base_url: str, host: str, keep_id: bool) -> dict:
    manifest = json.loads(TEMPLATE_PATH.read_text(encoding="utf-8"))
    app_id = manifest["id"] if keep_id else str(uuid.uuid4())
    content_url = f"{base_url}/index.html?teamsTab=1"
    manifest.update({
        "id": app_id,
        "developer": {
            "name": "Local Test",
            "websiteUrl": base_url,
            "privacyUrl": f"{base_url}/privacy.html",
            "termsOfUseUrl": f"{base_url}/terms.html"
        },
        "staticTabs": [{
            "entityId": "home",
            "name": "Hello",
            "contentUrl": content_url,
            "websiteUrl": f"{base_url}/index.html",
            "scopes": ["personal"]
        }],
        "validDomains": [host]
    })
    return manifest


def write_zip(manifest: dict) -> None:
    APP_PACKAGE.mkdir(exist_ok=True)
    manifest_path = APP_PACKAGE / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    for filename in ["color.png", "outline.png"]:
        if not (APP_PACKAGE / filename).exists():
            raise FileNotFoundError(f"Missing required icon: appPackage/{filename}")
    with zipfile.ZipFile(OUTPUT_ZIP, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.write(manifest_path, "manifest.json")
        zf.write(APP_PACKAGE / "color.png", "color.png")
        zf.write(APP_PACKAGE / "outline.png", "outline.png")


def main() -> None:
    parser = argparse.ArgumentParser(description="Create Teams app package ZIP from a public HTTPS URL.")
    parser.add_argument("public_url", help="Public HTTPS base URL, e.g. https://abc.trycloudflare.com")
    parser.add_argument("--keep-id", action="store_true", help="Keep the template app id instead of generating a fresh id.")
    args = parser.parse_args()
    try:
        base_url, host = normalize_base_url(args.public_url)
        manifest = build_manifest(base_url, host, keep_id=args.keep_id)
        write_zip(manifest)
    except Exception as exc:  # noqa: BLE001
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1)

    print("Generated Teams app package:")
    print(f"  {OUTPUT_ZIP}")
    print("Content URL:")
    print(f"  {manifest['staticTabs'][0]['contentUrl']}")
    print("Valid domain:")
    print(f"  {manifest['validDomains'][0]}")
    print("\nUpload the ZIP above in Teams: Apps > Manage your apps > Upload an app > Upload a custom app.")

if __name__ == "__main__":
    main()
