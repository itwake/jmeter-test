@echo off
py -3 start_server.py
