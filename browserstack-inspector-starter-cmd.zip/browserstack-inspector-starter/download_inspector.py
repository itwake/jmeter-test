"""Download a pinned official Inspector installer; verify SHA-256; never execute it."""
from __future__ import annotations
import argparse
import hashlib
import platform
import sys
import urllib.request
from pathlib import Path

VERSION = "2026.7.1"
HASHES = {
    ("mac", "arm64"): "3765e8d6c0501961773b2654a48837d6ab6004261189df6ea8007595d722b319",
    ("mac", "x64"): "3496f23d3ec2f3a9bbb82dc6e433d7c41cf453936b01b1e1db46a117d8d07889",
    ("win", "arm64"): "4ee4a74a08b5aeeaeb7bd973375f7b4347ef04cbcebf1d437864b50d6bf14513",
    ("win", "x64"): "289c764e3b1332da9f1d8569298b41d77114323f8b3aa79b8ac05ba5be64c60a",
}

def sha256(path: Path) -> str:
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(chunk)
    return result.hexdigest()

def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--os", choices=["mac", "win"])
    p.add_argument("--arch", choices=["arm64", "x64"])
    args = p.parse_args()
    os_name = args.os or {"Darwin": "mac", "Windows": "win"}.get(platform.system())
    machine = platform.machine().lower()
    arch = args.arch or {"arm64": "arm64", "aarch64": "arm64", "x86_64": "x64", "amd64": "x64"}.get(machine)
    if (os_name, arch) not in HASHES:
        p.error("Cannot detect a supported desktop platform. Use --os mac|win --arch x64|arm64.")
    extension = "dmg" if os_name == "mac" else "exe"
    filename = f"Appium-Inspector-{VERSION}-{os_name}-{arch}.{extension}"
    url = f"https://github.com/appium/appium-inspector/releases/download/v{VERSION}/{filename}"
    target = Path("downloads") / filename
    target.parent.mkdir(exist_ok=True)
    expected = HASHES[(os_name, arch)]
    if target.exists():
        if sha256(target) == expected:
            print(f"SHA-256 OK: {target.resolve()}")
            return 0
        raise RuntimeError(f"Existing file has wrong checksum: {target}. Remove or inspect it first.")
    part = target.with_suffix(target.suffix + ".part")
    print(f"Downloading official release {VERSION}: {os_name}/{arch}")
    req = urllib.request.Request(url, headers={"User-Agent": "EFP-Inspector-POC/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=120) as response, part.open("wb") as output:
            while chunk := response.read(1024 * 1024):
                output.write(chunk)
        if sha256(part) != expected:
            raise RuntimeError("SHA-256 mismatch. Installer was NOT executed. Inspect the download source.")
        part.replace(target)
    finally:
        if part.exists():
            part.unlink()
    print(f"SHA-256 OK: {target.resolve()}")
    print("Review the installer and use your organization's approved installation process.")
    return 0

if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        sys.exit(1)
