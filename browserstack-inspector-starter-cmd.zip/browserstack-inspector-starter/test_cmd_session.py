"""Offline tests; they do not start a Windows shell or contact BrowserStack."""
import unittest
from unittest.mock import patch
import getpass
import warnings
import cmd_session as c


class CmdSessionTests(unittest.TestCase):
    def test_base_env_unchanged(self):
        base = {'PATH': 'example'}
        env = c.make_env(base, False, lambda _: 'demo', lambda _: 'key')
        self.assertEqual(base, {'PATH': 'example'})
        self.assertEqual(env['BROWSERSTACK_USERNAME'], 'demo')
        self.assertNotIn('TEST_PASSWORD', env)

    def test_special_characters_preserved(self):
        secret = ' a%PATH%!^&|<>" secret '
        env = c.make_env({}, False, lambda _: 'demo', lambda _: secret)
        self.assertEqual(env['BROWSERSTACK_ACCESS_KEY'], secret)

    def test_app_credentials(self):
        names = iter(['bs-user', 'app-user'])
        secrets = iter(['key', 'pass'])
        env = c.make_env({}, True, lambda _: next(names), lambda _: next(secrets))
        self.assertEqual(env['TEST_USERNAME'], 'app-user')
        self.assertEqual(env['TEST_PASSWORD'], 'pass')

    def test_empty_secret_rejected(self):
        with self.assertRaises(ValueError):
            c.make_env({}, False, lambda _: 'demo', lambda _: '')

    def test_control_characters_rejected(self):
        for bad in ['abc\x00', 'abc\n', 'abc\r']:
            with self.subTest(bad=repr(bad)), self.assertRaises(ValueError):
                c.nonempty(bad, 'Value')

    def test_username_colon_rejected(self):
        with self.assertRaises(ValueError):
            c.make_env({}, False, lambda _: 'a:b', lambda _: 'key')

    def test_prompt_marker(self):
        env = c.make_env({'PROMPT': '$P$G'}, False, lambda _: 'demo', lambda _: 'key')
        self.assertEqual(env['PROMPT'], '[BS-CMD] $P$G')

    def test_visible_fallback_rejected(self):
        def insecure(_):
            warnings.warn('Cannot hide input', getpass.GetPassWarning)
            return 'not-used'
        with patch.object(c.getpass, 'getpass', insecure):
            with self.assertRaises(getpass.GetPassWarning):
                c.hidden_input('password: ')


if __name__ == '__main__':
    unittest.main()
