# BrowserStack Inspector Starter — CMD 版

请从 **WINDOWS_CMD.md** 开始。该文档提供从安装到录制、回放、换机型、iOS、Local 隧道和清理的 Windows CMD 步骤。

本包基于前一版辅助包，保留核心 Python 配置与回放脚本，增加 cmd_session.py 隐藏输入凭据并启动 CMD 子会话。WINDOWS.md 也已替换为 CMD 版。

不依赖 PowerShell；不需要修改 ExecutionPolicy。Installer、下载、云设备连接等操作仍需遵守企业授权与网络政策。

- `download_inspector.py`：下载原包固定版本的官方 Inspector 安装器，校验 SHA-256。
- `configure.py`：使用设备 API 数据生成不含凭据的 capabilities。
- `cmd_session.py`：隐藏输入凭据、启动临时 CMD 子会话。
- `run.py`：单会话连通性检查或调用已审核录制代码。
- `recorded_steps.py`：必须由你填入真实录制操作，默认不会执行。
- `test_configure.py`、`test_cmd_session.py`：离线测试。

测试通过不代表 Windows 或云端实机验证通过。此包不是 BrowserStack 官方产品，不包含并发调度器或 AI 自修复。
