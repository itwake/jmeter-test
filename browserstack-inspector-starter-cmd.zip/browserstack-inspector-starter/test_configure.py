"""Offline unit tests. These do not connect to BrowserStack."""
import unittest
from configure import build_caps, filter_devices
from download_inspector import HASHES

class ConfigureTests(unittest.TestCase):
    def setUp(self):
        self.android = {"os": "android", "device": "Synthetic Android", "os_version": "14.0"}
        self.ios = {"os": "ios", "device": "Synthetic iPhone", "os_version": "18.0"}
    def test_android(self):
        c = build_caps(self.android, "bs://example-test-only")
        self.assertEqual(c["appium:automationName"], "UiAutomator2")
        self.assertNotIn("local", c["bstack:options"])
    def test_ios(self):
        self.assertEqual(build_caps(self.ios, "bs://test")["appium:automationName"], "XCUITest")
    def test_tunnel(self):
        c = build_caps(self.android, "bs://test", "test-local")
        self.assertIs(c["bstack:options"]["local"], True)
        self.assertEqual(c["bstack:options"]["localIdentifier"], "test-local")
    def test_no_secrets(self):
        c = build_caps(self.android, "bs://test")
        self.assertNotIn("userName", c["bstack:options"])
        self.assertNotIn("accessKey", c["bstack:options"])
    def test_reject_placeholder(self):
        with self.assertRaises(ValueError):
            build_caps(self.android, "bs://<APP_ID>")
    def test_filter(self):
        self.assertEqual(filter_devices([self.android, self.ios], "ios", "IPHONE"), [self.ios])
    def test_error_response(self):
        with self.assertRaises(ValueError):
            filter_devices({"error": "unauthorized"}, "ios")
    def test_hashes(self):
        self.assertEqual(len(HASHES), 4)
        for value in HASHES.values():
            self.assertEqual(len(value), 64)
            int(value, 16)

if __name__ == "__main__":
    unittest.main()
