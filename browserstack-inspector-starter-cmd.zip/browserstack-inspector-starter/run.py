"""One BrowserStack session per invocation. Smoke check or replay locally reviewed Inspector steps."""
from __future__ import annotations
import argparse
import importlib.util
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4
from typing import Any

HUB = "https://hub.browserstack.com/wd/hub"


def sanitize(value: object) -> str:
    text = str(value)
    for name in ("BROWSERSTACK_ACCESS_KEY", "BROWSERSTACK_USERNAME", "TEST_PASSWORD", "TEST_USERNAME"):
        secret = os.environ.get(name)
        if secret:
            text = text.replace(secret, "[REDACTED]")
    return text[:3000]


def read_caps(path: Path) -> dict[str, Any]:
    caps = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(caps, dict):
        raise ValueError("Capabilities must be a JSON object, not an outer capabilities/alwaysMatch request.")
    if str(caps.get("platformName", "")).lower() not in {"android", "ios"}:
        raise ValueError("platformName must be Android or iOS.")
    if not str(caps.get("appium:app", "")).startswith("bs://"):
        raise ValueError("Missing appium:app. Use the uploaded bs:// identifier.")
    bstack = caps.setdefault("bstack:options", {})
    if not isinstance(bstack, dict):
        raise ValueError("bstack:options must be an object.")
    for env_key, cap_key in (("BROWSERSTACK_USERNAME", "userName"), ("BROWSERSTACK_ACCESS_KEY", "accessKey")):
        value = os.environ.get(env_key)
        if not value:
            raise ValueError(f"Set {env_key} in this terminal before running.")
        bstack[cap_key] = value
    return caps


def load_steps(path: Path):
    spec = importlib.util.spec_from_file_location("local_recorded_steps", path.resolve())
    if spec is None or spec.loader is None:
        raise ValueError(f"Cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if not getattr(module, "READY", False):
        raise ValueError("Recording template is not ready. Paste reviewed steps into run(driver), remove the placeholder error, and set READY = True.")
    if not callable(getattr(module, "run", None)):
        raise ValueError("Steps file must define run(driver).")
    return module


def capture(driver: Any, folder: Path, name: str) -> None:
    source = driver.page_source
    if not source:
        raise RuntimeError("Server returned an empty page source.")
    (folder / f"{name}.xml").write_text(source, encoding="utf-8")
    if not driver.save_screenshot(str(folder / f"{name}.png")):
        raise RuntimeError("Screenshot could not be saved.")


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--caps", type=Path, required=True)
    p.add_argument("--mode", choices=["smoke", "replay"], default="smoke")
    p.add_argument("--steps", type=Path, default=Path("recorded_steps.py"))
    p.add_argument("--http-timeout", type=int, default=300)
    args = p.parse_args()
    if args.http_timeout <= 0:
        p.error("--http-timeout must be positive")
    # Validate BEFORE opening a paid cloud session.
    caps = read_caps(args.caps)
    steps = load_steps(args.steps) if args.mode == "replay" else None
    from appium import webdriver
    from appium.options.android import UiAutomator2Options
    from appium.options.ios import XCUITestOptions
    from appium.webdriver.client_config import AppiumClientConfig

    os.umask(0o077)
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid4().hex[:8]
    caps["bstack:options"]["sessionName"] = f"{args.mode}-{run_id}"
    cls = UiAutomator2Options if caps["platformName"].lower() == "android" else XCUITestOptions
    options = cls().load_capabilities(caps)
    client = AppiumClientConfig(remote_server_addr=HUB, timeout=args.http_timeout, direct_connection=False)
    ca = os.environ.get("BS_CA_CERTS")
    if ca:
        if not Path(ca).is_file():
            raise ValueError("BS_CA_CERTS must point to an existing PEM CA bundle.")
        client.ca_certs = ca
    folder = Path("artifacts") / run_id
    folder.mkdir(parents=True, mode=0o700)
    driver = None
    result = 0
    try:
        driver = webdriver.Remote(options=options, client_config=client)
        (folder / "session-id.txt").write_text(str(driver.session_id) + "\n", encoding="utf-8")
        print(f"Session: {driver.session_id}")
        print(f"Artifacts: {folder.resolve()}")
        capture(driver, folder, "start")
        if steps is not None:
            steps.run(driver)
            capture(driver, folder, "end")
            print("Replay completed without an exception. Business correctness depends on YOUR explicit assertions.")
        else:
            print("SMOKE OK: session, page source and screenshot succeeded. This is NOT a business test.")
    except Exception as exc:
        result = 1
        message = f"{type(exc).__name__}: {sanitize(exc)}"
        print(message, file=sys.stderr)
        (folder / "error.txt").write_text(message + "\n", encoding="utf-8")
        if driver is not None:
            try:
                capture(driver, folder, "failure")
            except Exception as capture_error:
                print(f"Evidence capture also failed: {sanitize(capture_error)}", file=sys.stderr)
        print("No automatic retry was attempted. Check session/transaction state before retrying.", file=sys.stderr)
    finally:
        if driver is not None:
            try:
                driver.quit()
                print("Session closed.")
            except Exception as close_error:
                result = 1
                print(f"Could not confirm session closure: {sanitize(close_error)}", file=sys.stderr)
                print("Check App Automate Dashboard and stop a remaining session manually.", file=sys.stderr)
    return result

if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as exc:
        print(f"ERROR: {type(exc).__name__}: {sanitize(exc)}", file=sys.stderr)
        sys.exit(1)
