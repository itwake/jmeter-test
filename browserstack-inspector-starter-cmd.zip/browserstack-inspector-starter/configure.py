"""Create a credential-free W3C capabilities file from BrowserStack device-list JSON."""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path
from typing import Any


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def filter_devices(data: Any, platform_name: str, contains: str = "") -> list[dict[str, Any]]:
    if not isinstance(data, list):
        raise ValueError("devices.json is not an array. Check credentials, API response and App Automate access.")
    result = []
    for d in data:
        if not isinstance(d, dict):
            continue
        if str(d.get("os", "")).lower() != platform_name:
            continue
        if not d.get("device") or "os_version" not in d:
            continue
        if contains.lower() not in str(d["device"]).lower():
            continue
        result.append(d)
    return result


def build_caps(device: dict[str, Any], app_url: str, local_id: str | None = None) -> dict[str, Any]:
    if not isinstance(app_url, str) or not app_url.startswith("bs://") or len(app_url) <= 5:
        raise ValueError("Use the real bs:// app_url returned by the upload API.")
    if any(c in app_url for c in ("<", ">", "\n", "\r")):
        raise ValueError("Replace the placeholder app_url with the real uploaded app identifier.")
    name = str(device["os"]).lower()
    if name not in {"android", "ios"}:
        raise ValueError("Only android and ios are supported by this starter.")
    bstack: dict[str, Any] = {
        "projectName": "EFP Inspector POC",
        "buildName": "manual-recording-poc",
        "sessionName": f"record-{name}",
        "idleTimeout": 300,
        "networkLogs": False,
    }
    if local_id:
        bstack.update({"local": True, "localIdentifier": local_id})
    return {
        "platformName": "Android" if name == "android" else "iOS",
        "appium:automationName": "UiAutomator2" if name == "android" else "XCUITest",
        "appium:deviceName": str(device["device"]),
        "appium:platformVersion": str(device["os_version"]),
        "appium:app": app_url,
        "appium:newCommandTimeout": 300,
        "bstack:options": bstack,
    }


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--platform", choices=["android", "ios"], required=True)
    p.add_argument("--devices", type=Path, default=Path("devices.json"))
    app_group = p.add_mutually_exclusive_group(required=True)
    app_group.add_argument("--app-file", type=Path, help="JSON response saved by curl upload")
    app_group.add_argument("--app", help="Existing bs:// app_url from App Automate")
    p.add_argument("--contains", default="", help="Optional device-name filter, e.g. Samsung or iPhone")
    p.add_argument("--index", type=int, help="1-based selection; without this flag, prompts interactively")
    p.add_argument("--local-id", help="Use ONLY when a matching authorized BrowserStack Local tunnel is ready")
    p.add_argument("--out", type=Path, required=True)
    args = p.parse_args()
    if args.out.exists():
        raise ValueError(f"{args.out} exists. Choose a new --out name or intentionally remove the old file.")
    devices = filter_devices(load_json(args.devices), args.platform, args.contains)
    if not devices:
        raise ValueError("No matching devices. Refresh devices.json or remove --contains.")
    for i, d in enumerate(devices, 1):
        print(f"{i:3d}. {d['device']} | {d['os']} {d['os_version']}")
    index = args.index if args.index is not None else int(input("Choose a device number: ").strip())
    if not 1 <= index <= len(devices):
        raise ValueError("Device number is out of range.")
    app_url = args.app
    if args.app_file:
        upload = load_json(args.app_file)
        if not isinstance(upload, dict) or "app_url" not in upload:
            raise ValueError("Upload response has no app_url. Check the upload result before proceeding.")
        app_url = upload["app_url"]
    caps = build_caps(devices[index - 1], app_url, args.local_id)
    args.out.write_text(json.dumps(caps, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Created: {args.out}")
    print("No credentials were written. In Inspector, enter credentials in its BrowserStack provider tab.")
    print("This is a supported-device catalogue entry, not a guarantee of an immediately free device.")
    return 0

if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, ValueError, KeyError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        sys.exit(1)
