"""Prompt for credentials without echo, then run an isolated Windows CMD session.

No PowerShell, generated secret files, permanent variables, or credential-bearing
shell strings. Child programs still inherit the credentials in their environment;
this is not a credential vault. Use 'exit' to return to the original terminal.
"""
from __future__ import annotations

import argparse
import getpass
import os
from pathlib import Path
import subprocess
import sys
from typing import Callable, Mapping
import warnings


def nonempty(value: str, label: str) -> str:
    if not value or any(c in value for c in ('\x00', '\r', '\n')):
        raise ValueError(f'{label} must be nonempty and contain no NUL/newline.')
    return value


def hidden_input(prompt: str) -> str:
    # Refuse to fall back to visible password input in a non-console environment.
    with warnings.catch_warnings():
        warnings.simplefilter('error', getpass.GetPassWarning)
        return getpass.getpass(prompt)


def make_env(
    base: Mapping[str, str],
    with_test: bool,
    ask: Callable[[str], str] = input,
    ask_secret: Callable[[str], str] = hidden_input,
) -> dict[str, str]:
    env = dict(base)  # Never mutate the parent environment.
    username = nonempty(ask('BrowserStack Username: ').strip(), 'Username')
    if ':' in username:
        raise ValueError('BrowserStack Username must not contain a colon.')
    env['BROWSERSTACK_USERNAME'] = username
    env['BROWSERSTACK_ACCESS_KEY'] = nonempty(
        ask_secret('BrowserStack Access Key (hidden): '), 'Access Key'
    )
    if with_test:
        env['TEST_USERNAME'] = nonempty(ask('Test Username: ').strip(), 'Test Username')
        env['TEST_PASSWORD'] = nonempty(ask_secret('Test Password (hidden): '), 'Test Password')
    env['PROMPT'] = '[BS-CMD] ' + env.get('PROMPT', '$P$G')
    return env


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--test', action='store_true', help='Also prompt for test-app username/password.')
    args = parser.parse_args(argv)
    if sys.platform != 'win32':
        parser.error('Run this helper in Windows CMD, not macOS/Linux.')
    cmd = Path(os.environ.get('SystemRoot', r'C:\Windows')) / 'System32' / 'cmd.exe'
    if not cmd.is_file():
        raise OSError('Cannot locate the Windows system cmd.exe.')
    if not sys.stdin.isatty():
        raise ValueError('Use an interactive Windows terminal; redirected input is not supported.')
    env = make_env(os.environ, args.test)
    print('\nEntering CMD in the same terminal. Continue at the [BS-CMD] prompt.')
    print('Credentials are held in process environments, not saved to disk by this helper.')
    print("Finish sessions/tunnels before typing 'exit' to return to the original CMD.\n", flush=True)
    try:
        return subprocess.call([str(cmd), '/D', '/E:ON', '/V:OFF', '/K'], env=env)
    finally:
        for name in ('BROWSERSTACK_ACCESS_KEY', 'TEST_PASSWORD'):
            env.pop(name, None)


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (EOFError, KeyboardInterrupt):
        print('\nCancelled. Check any running device session or Local tunnel.', file=sys.stderr)
        sys.exit(130)
    except getpass.GetPassWarning:
        print('ERROR: Hidden input is unavailable. Run in an interactive Windows CMD console.', file=sys.stderr)
        sys.exit(1)
    except (OSError, ValueError) as exc:
        print(f'ERROR: {exc}', file=sys.stderr)
        sys.exit(1)
